//
//  main.cpp
//  AlgorithmProject
//
//  Created by Grant Lanham, Jr on 10/7/17.
//  Copyright © 2017 Grant Lanham, Jr. All rights reserved.
//
//  FLORIDA ATLANTIC UNIVERSITY
//
//

ALGORITHM ANALYSIS FOR INSERT-SORT QUICK-SORT MERGE-SORT

Enter '0' then '0' to execute given assignment.

---INTRODUCTION--- 

This program uses a single character input menu. When a menu is
displayed, it will ask for an input of some numeric entry such as '0'
or '1'. Entering more than one character is not accepted as well
as no input at all. The functionality is basic for running the intended
purpose and allowing for basic customization.

